#!/usr/bin/env python3
"""
Main launch file for Striker Bot hardware
"""
import os
from launch import LaunchDescription
from launch_ros.actions import Node, LifecycleNode
from launch.actions import IncludeLaunchDescription, ExecuteProcess, TimerAction
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution
from launch_ros.substitutions import FindPackageShare

def generate_launch_description():
    # Package paths
    pkg_path = FindPackageShare('striker_bot_hardware')
    nav2_path = FindPackageShare('nav2_bringup')
    
    return LaunchDescription([
        # ==================== SENSORS ====================
        
        # RealSense D456i (IMU only)
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',
            name='realsense_camera',
            parameters=[{
                'camera_name': 'camera',
                'enable_gyro': True,
                'enable_accel': True,
                'enable_color': False,
                'enable_depth': False,
                'enable_infra1': False,
                'enable_infra2': False,
                'gyro_fps': 200,
                'accel_fps': 200,
                'unite_imu_method': 1,  # Copy gyro to accel timestamps
                'topic_odom_in': 'odom',  # For future odometry
                'initial_reset': True,
                'publish_odom_tf': False,
            }],
            remappings=[
                ('/camera/imu', '/imu/data'),
                ('/camera/gyro/sample', '/imu/gyro'),
                ('/camera/accel/sample', '/imu/accel'),
            ]
        ),
        
        # GPS Driver (u-blox F9P)
        Node(
            package='striker_bot_hardware',
            executable='gps_driver',
            name='gps_driver',
            parameters=[{
                'port': '/dev/ttyACM0',
                'baudrate': 115200,
                'frame_id': 'gps_link',
            }],
            output='screen'
        ),
        
        # ==================== LOCALIZATION ====================
        
        # EKF for sensor fusion (GPS + IMU)
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[PathJoinSubstitution([pkg_path, 'config', 'ekf_hardware.yaml'])],
        ),
        
        # Navsat Transform (GPS to map conversion)
        Node(
            package='robot_localization',
            executable='navsat_transform_node',
            name='navsat_transform',
            output='screen',
            parameters=[PathJoinSubstitution([pkg_path, 'config', 'ekf_hardware.yaml'])],
            remappings=[
                ('/gps/fix', '/gps/fix'),
                ('/imu', '/imu/data'),
                ('/odometry/filtered', '/odometry/global'),
            ]
        ),
        
        # ==================== NAVIGATION ====================
        
        # Nav2 Stack
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                PathJoinSubstitution([nav2_path, 'launch', 'navigation_launch.py'])
            ]),
            launch_arguments={
                'use_sim_time': 'false',
                'params_file': PathJoinSubstitution([pkg_path, 'config', 'nav2_hardware.yaml']),
                'use_composition': 'False',
                'autostart': 'True',
            }.items()
        ),
        
        # ==================== ACTUATORS ====================
        
        # Motor Controller (ESP32)
        Node(
            package='striker_bot_hardware',
            executable='motor_controller',
            name='motor_controller',
            parameters=[{
                'port': '/dev/ttyUSB0',
                'baudrate': 115200,
                'wheel_separation': 0.75,
                'wheel_radius': 0.15,
            }],
            output='screen'
        ),
        
        # ==================== TRANSFORMS ====================
        
        # Static transforms for your robot
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'camera_link'],
            name='camera_tf'
        ),
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0.2', '0', '0.5', '0', '0', '0', 'base_link', 'gps_link'],
            name='gps_tf'
        ),
        
        # ==================== UTILITIES ====================
        
        # Robot State Publisher (if you have a URDF)
        # Node(
        #     package='robot_state_publisher',
        #     executable='robot_state_publisher',
        #     name='robot_state_publisher',
        #     parameters=[{'robot_description': robot_description}]
        # ),
        
        # RViz for visualization (optional)
        # Node(
        #     package='rviz2',
        #     executable='rviz2',
        #     name='rviz2',
        #     arguments=['-d', PathJoinSubstitution([pkg_path, 'config', 'nav2_default_view.rviz'])],
        #     condition=IfCondition(use_rviz)
        # ),
    ])