from setuptools import setup
import os
from glob import glob

package_name = 'striker_bot_hardware'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        # Install launch files
        (os.path.join('share', package_name, 'launch'), 
         glob('launch/*.py')),
        # Install config files
        (os.path.join('share', package_name, 'config'), 
         glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='you',
    maintainer_email='you@example.com',
    description='Hardware interface for Striker Bot with GPS navigation',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            # Core hardware drivers
            'gps_driver = striker_bot_hardware.gps_driver:main',
            'motor_controller = striker_bot_hardware.motor_controller:main',
            
            # Navigation
            'gps_waypoint_logger = striker_bot_hardware.gps_waypoint_logger:main',
            'gps_navigator = striker_bot_hardware.gps_navigator:main',
            
            # Utilities
            'check_gps_hardware = striker_bot_hardware.gps_driver:check_gps',
            
            # Testing
            'test_gps_basic = striker_bot_hardware.test_gps_basic:main',
        ],
    },
)