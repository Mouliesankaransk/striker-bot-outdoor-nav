#!/usr/bin/env python3
"""
GPS Driver for u-blox F9P module
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
import serial
import threading
import time
from datetime import datetime

class UbloxGPSDriver(Node):
    def __init__(self):
        super().__init__('ublox_gps_driver')
        
        # Parameters
        self.declare_parameter('port', '/dev/ttyACM0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('frame_id', 'gps_link')
        self.declare_parameter('publish_rate', 1.0)  # Hz
        
        # Publisher
        self.gps_pub = self.create_publisher(NavSatFix, '/gps/fix', 10)
        
        # Status publisher (optional)
        self.status_timer = self.create_timer(5.0, self.publish_status)
        
        # Start GPS thread
        self.gps_thread = threading.Thread(target=self.gps_reading_thread)
        self.gps_thread.daemon = True
        self.gps_thread.start()
        
        self.get_logger().info("Ublox F9P GPS Driver started")
    
    def gps_reading_thread(self):
        """Main GPS reading thread"""
        port = self.get_parameter('port').value
        baudrate = self.get_parameter('baudrate').value
        frame_id = self.get_parameter('frame_id').value
        rate = 1.0 / self.get_parameter('publish_rate').value
        
        try:
            # Try different baudrates
            for baud in [baudrate, 9600, 38400, 57600]:
                try:
                    self.ser = serial.Serial(port, baud, timeout=1)
                    self.get_logger().info(f"Connected to GPS at {port}, baud {baud}")
                    break
                except:
                    continue
            else:
                self.get_logger().error(f"Failed to connect to GPS at {port}")
                return
            
            # Configure u-blox for better output (optional)
            self.configure_ublox()
            
            # Main reading loop
            while rclpy.ok():
                try:
                    line = self.ser.readline().decode('ascii', errors='ignore').strip()
                    
                    if line.startswith('$GNGGA') or line.startswith('$GPGGA'):
                        self.parse_gga(line, frame_id)
                    
                    # Also parse RMC for velocity (optional)
                    elif line.startswith('$GNRMC') or line.startswith('$GPRMC'):
                        self.parse_rmc(line)
                        
                except UnicodeDecodeError:
                    continue
                except Exception as e:
                    self.get_logger().warn(f"GPS read error: {e}")
                
                time.sleep(rate)
                
        except Exception as e:
            self.get_logger().error(f"GPS thread error: {e}")
    
    def parse_gga(self, nmea_str, frame_id):
        """Parse GGA NMEA sentence"""
        try:
            # Split NMEA sentence
            parts = nmea_str.split(',')
            
            if len(parts) < 10:
                return
            
            # Create GPS message
            msg = NavSatFix()
            msg.header.stamp = self.get_clock().now().to_msg()
            msg.header.frame_id = frame_id
            
            # Parse latitude (format: DDMM.MMMM)
            lat_str = parts[2]
            lat_dir = parts[3]
            if lat_str and lat_dir:
                lat_deg = float(lat_str[:2])
                lat_min = float(lat_str[2:])
                msg.latitude = lat_deg + (lat_min / 60.0)
                if lat_dir == 'S':
                    msg.latitude = -msg.latitude
            
            # Parse longitude (format: DDDMM.MMMM)
            lon_str = parts[4]
            lon_dir = parts[5]
            if lon_str and lon_dir:
                lon_deg = float(lon_str[:3])
                lon_min = float(lon_str[3:])
                msg.longitude = lon_deg + (lon_min / 60.0)
                if lon_dir == 'W':
                    msg.longitude = -msg.longitude
            
            # Parse altitude
            if parts[9]:
                msg.altitude = float(parts[9])
            
            # Quality indicator
            fix_quality = int(parts[6]) if parts[6] else 0
            if fix_quality >= 1:
                msg.status.status = 2  # FIX
            else:
                msg.status.status = 0  # NO_FIX
            
            msg.status.service = 1  # GPS
            
            # Add covariance (estimated)
            hdop = float(parts[8]) if parts[8] else 1.0
            position_variance = (hdop * 3.0) ** 2  # Approximate 3σ
            msg.position_covariance[0] = position_variance
            msg.position_covariance[4] = position_variance
            msg.position_covariance[8] = (hdop * 5.0) ** 2  # Altitude less accurate
            msg.position_covariance_type = 2  # COVARIANCE_TYPE_APPROXIMATED
            
            self.gps_pub.publish(msg)
            
            # Log first fix
            if fix_quality >= 1 and not hasattr(self, 'got_first_fix'):
                self.got_first_fix = True
                self.get_logger().info(f"First GPS fix: {msg.latitude:.6f}, {msg.longitude:.6f}")
            
        except Exception as e:
            self.get_logger().warn(f"Parse GGA error: {e}")
    
    def parse_rmc(self, nmea_str):
        """Parse RMC NMEA sentence for velocity (optional)"""
        # You can implement velocity parsing here
        pass
    
    def configure_ublox(self):
        """Configure u-blox for better output (optional)"""
        try:
            # Enable GGA and RMC sentences
            configs = [
                b'$PUBX,40,GGA,0,1,0,0*5A\r\n',  # Enable GGA
                b'$PUBX,40,RMC,0,1,0,0*47\r\n',  # Enable RMC
                b'$PUBX,40,GSA,0,0,0,0*4E\r\n',  # Disable GSA
                b'$PUBX,40,GSV,0,0,0,0*59\r\n',  # Disable GSV
                b'$PUBX,40,VTG,0,0,0,0*5E\r\n',  # Disable VTG
            ]
            
            for cmd in configs:
                self.ser.write(cmd)
                time.sleep(0.1)
            
            self.get_logger().info("u-blox configured")
            
        except Exception as e:
            self.get_logger().warn(f"u-blox config failed: {e}")
    
    def publish_status(self):
        """Periodic status update"""
        if hasattr(self, 'got_first_fix'):
            self.get_logger().info("GPS: Fix acquired")
        else:
            self.get_logger().warn("GPS: Waiting for fix")

def main():
    rclpy.init()
    node = UbloxGPSDriver()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()