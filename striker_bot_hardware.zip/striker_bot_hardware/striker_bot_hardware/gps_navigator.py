#!/usr/bin/env python3
"""
GPS Navigator for real hardware
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped
from nav2_msgs.action import NavigateToPose, FollowWaypoints
from rclpy.action import ActionClient
import yaml
import os
import sys
import time
import math
from .gps_utils import gps_to_utm, haversine_distance

class HardwareGPSNavigator(Node):
    def __init__(self):
        super().__init__('hardware_gps_navigator')
        
        # Action clients
        self.nav_to_pose_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        self.follow_waypoints_client = ActionClient(self, FollowWaypoints, 'follow_waypoints')
        
        # Wait for servers
        self.get_logger().info("Waiting for navigation servers...")
        self.nav_to_pose_client.wait_for_server()
        self.follow_waypoints_client.wait_for_server()
        self.get_logger().info("Navigation servers ready!")
        
        # Origin point (set from first waypoint or manually)
        self.origin_lat = None
        self.origin_lon = None
    
    def set_origin(self, lat, lon):
        """Set the origin point for GPS to map conversion"""
        self.origin_lat = lat
        self.origin_lon = lon
        self.get_logger().info(f"Origin set: ({lat:.6f}, {lon:.6f})")
    
    def gps_to_map(self, lat, lon):
        """Convert GPS to map coordinates"""
        if self.origin_lat is None or self.origin_lon is None:
            self.get_logger().error("Origin not set!")
            return 0.0, 0.0
        
        return gps_to_utm(lat, lon, self.origin_lat, self.origin_lon)
    
    def navigate_to_gps(self, latitude, longitude):
        """Navigate to a single GPS coordinate"""
        x, y = self.gps_to_map(latitude, longitude)
        
        pose = PoseStamped()
        pose.header.frame_id = 'map'
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x = float(x)
        pose.pose.position.y = float(y)
        pose.pose.position.z = 0.0
        pose.pose.orientation.w = 1.0
        
        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = pose
        
        self.get_logger().info(f"Navigating to GPS ({latitude:.6f}, {longitude:.6f}) -> Map ({x:.2f}, {y:.2f})")
        
        future = self.nav_to_pose_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future)
        
        if future.result() is not None:
            goal_handle = future.result()
            return goal_handle.accepted
        return False
    
    def follow_gps_waypoints(self, waypoints):
        """Follow a list of GPS waypoints"""
        if not waypoints:
            self.get_logger().error("No waypoints provided!")
            return False
        
        # Set origin from first waypoint if not set
        if self.origin_lat is None:
            self.set_origin(waypoints[0][0], waypoints[0][1])
        
        poses = []
        for i, (lat, lon) in enumerate(waypoints):
            x, y = self.gps_to_map(lat, lon)
            
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.header.stamp = self.get_clock().now().to_msg()
            pose.pose.position.x = float(x)
            pose.pose.position.y = float(y)
            pose.pose.position.z = 0.0
            pose.pose.orientation.w = 1.0
            poses.append(pose)
            
            self.get_logger().info(f"Waypoint {i+1}: ({lat:.6f}, {lon:.6f}) -> ({x:.2f}, {y:.2f})")
        
        goal_msg = FollowWaypoints.Goal()
        goal_msg.poses = poses
        
        self.get_logger().info(f"Following {len(waypoints)} waypoints")
        
        future = self.follow_waypoints_client.send_goal_async(goal_msg)
        rclpy.spin_until_future_complete(self, future)
        
        if future.result() is not None:
            goal_handle = future.result()
            return goal_handle.accepted
        return False

def main():
    rclpy.init()
    
    # Parse arguments
    if len(sys.argv) < 2:
        print("Usage: ros2 run striker_bot_hardware gps_navigator <waypoints_file.yaml>")
        print("Or: ros2 run striker_bot_hardware gps_navigator lat lon [lat lon ...]")
        return
    
    navigator = HardwareGPSNavigator()
    
    # Check if first argument is a file
    if os.path.exists(sys.argv[1]):
        # Load from YAML file
        with open(sys.argv[1], 'r') as f:
            data = yaml.safe_load(f)
        
        if 'waypoints' not in data:
            print("Error: No 'waypoints' in YAML file")
            return
        
        waypoints = [(wp['latitude'], wp['longitude']) for wp in data['waypoints']]
        
        print(f"Loaded {len(waypoints)} waypoints from {sys.argv[1]}")
        print("Starting navigation in 5 seconds...")
        time.sleep(5)
        
        success = navigator.follow_gps_waypoints(waypoints)
        
        if success:
            print("✓ Waypoint following started")
        else:
            print("✗ Failed to start waypoint following")
    
    else:
        # Parse coordinates from command line
        try:
            coords = []
            for i in range(1, len(sys.argv), 2):
                if i+1 < len(sys.argv):
                    lat = float(sys.argv[i])
                    lon = float(sys.argv[i+1])
                    coords.append((lat, lon))
            
            if coords:
                print(f"Navigating to {len(coords)} coordinate(s)")
                print("Starting in 5 seconds...")
                time.sleep(5)
                
                # Navigate to each coordinate sequentially
                for i, (lat, lon) in enumerate(coords):
                    print(f"\nWaypoint {i+1}/{len(coords)}: ({lat:.6f}, {lon:.6f})")
                    
                    success = navigator.navigate_to_gps(lat, lon)
                    
                    if success:
                        print("✓ Navigation started")
                        
                        # Wait for completion (simplified - in real use, monitor feedback)
                        if i < len(coords) - 1:
                            wait_time = 30  # seconds
                            print(f"Waiting {wait_time} seconds before next waypoint...")
                            time.sleep(wait_time)
                    else:
                        print("✗ Navigation failed")
                        break
            
        except ValueError:
            print("Error: Invalid coordinates")
            print("Usage: ros2 run striker_bot_hardware gps_navigator lat lon [lat lon ...]")
    
    # Keep node alive to monitor navigation
    try:
        rclpy.spin(navigator)
    except KeyboardInterrupt:
        print("\nNavigation interrupted")
    
    navigator.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()