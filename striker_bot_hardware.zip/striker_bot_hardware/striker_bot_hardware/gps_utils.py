#!/usr/bin/env python3
"""
GPS utility functions
"""
import math

def haversine_distance(lat1, lon1, lat2, lon2):
    """
    Calculate distance between two GPS points in meters using Haversine formula
    """
    R = 6371000  # Earth radius in meters
    
    lat1_rad = math.radians(lat1)
    lon1_rad = math.radians(lon1)
    lat2_rad = math.radians(lat2)
    lon2_rad = math.radians(lon2)
    
    dlat = lat2_rad - lat1_rad
    dlon = lon2_rad - lon1_rad
    
    a = math.sin(dlat/2)**2 + math.cos(lat1_rad) * math.cos(lat2_rad) * math.sin(dlon/2)**2
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    
    return R * c

def gps_to_utm(lat, lon, origin_lat, origin_lon):
    """
    Convert GPS to local UTM-like coordinates relative to origin
    Simple approximation for small areas (< 10km)
    """
    # Meters per degree
    lat_m_per_deg = 111111.0
    lon_m_per_deg = math.cos(math.radians(origin_lat)) * 111111.0
    
    x = (lon - origin_lon) * lon_m_per_deg
    y = (lat - origin_lat) * lat_m_per_deg
    
    return x, y

def utm_to_gps(x, y, origin_lat, origin_lon):
    """
    Convert local UTM coordinates back to GPS
    """
    lat_m_per_deg = 111111.0
    lon_m_per_deg = math.cos(math.radians(origin_lat)) * 111111.0
    
    lon = origin_lon + (x / lon_m_per_deg)
    lat = origin_lat + (y / lat_m_per_deg)
    
    return lat, lon

def quaternion_from_euler(roll, pitch, yaw):
    """Convert Euler angles to quaternion"""
    cy = math.cos(yaw * 0.5)
    sy = math.sin(yaw * 0.5)
    cp = math.cos(pitch * 0.5)
    sp = math.sin(pitch * 0.5)
    cr = math.cos(roll * 0.5)
    sr = math.sin(roll * 0.5)
    
    w = cr * cp * cy + sr * sp * sy
    x = sr * cp * cy - cr * sp * sy
    y = cr * sp * cy + sr * cp * sy
    z = cr * cp * sy - sr * sp * cy
    
    return [x, y, z, w]

def euler_from_quaternion(x, y, z, w):
    """Convert quaternion to Euler angles"""
    t0 = +2.0 * (w * x + y * z)
    t1 = +1.0 - 2.0 * (x * x + y * y)
    roll_x = math.atan2(t0, t1)
    
    t2 = +2.0 * (w * y - z * x)
    t2 = +1.0 if t2 > +1.0 else t2
    t2 = -1.0 if t2 < -1.0 else t2
    pitch_y = math.asin(t2)
    
    t3 = +2.0 * (w * z + x * y)
    t4 = +1.0 - 2.0 * (y * y + z * z)
    yaw_z = math.atan2(t3, t4)
    
    return roll_x, pitch_y, yaw_z