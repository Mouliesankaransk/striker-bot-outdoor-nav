#!/usr/bin/env python3
"""
Main launch file for hardware setup
"""
import os
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_path = get_package_share_directory('striker_bot_hardware')
    
    return LaunchDescription([
        # RealSense D456i
        Node(
            package='realsense2_camera',
            executable='realsense2_camera_node',
            name='realsense_camera',
            parameters=[{
                'enable_gyro': True,
                'enable_accel': True,
                'enable_color': False,
                'enable_depth': False,
                'gyro_fps': 200,
                'accel_fps': 200,
                'unite_imu_method': 1,  # Copy gyro to accel timestamps
            }]
        ),
        
        # GPS Driver (u-blox F9P)
        Node(
            package='striker_bot_hardware',
            executable='gps_driver',
            name='gps_driver',
            parameters=[{'port': '/dev/ttyACM0', 'baudrate': 115200}]
        ),
        
        # EKF for sensor fusion
        Node(
            package='robot_localization',
            executable='ekf_node',
            name='ekf_filter_node',
            output='screen',
            parameters=[os.path.join(pkg_path, 'config', 'ekf_hardware.yaml')]
        ),
        
        # Motor Controller (ESP32)
        Node(
            package='striker_bot_hardware',
            executable='motor_controller',
            name='motor_controller',
            parameters=[{'port': '/dev/ttyUSB0', 'baudrate': 115200}]
        ),
        
        # Nav2 Navigation
        IncludeLaunchDescription(
            PythonLaunchDescriptionSource([
                os.path.join(get_package_share_directory('nav2_bringup'), 'launch', 'navigation_launch.py')
            ]),
            launch_arguments={
                'use_sim_time': 'false',
                'params_file': os.path.join(pkg_path, 'config', 'nav2_hardware.yaml')
            }.items()
        ),
        
        # Static TF Publisher (adjust for your robot)
        Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            arguments=['0', '0', '0.1', '0', '0', '0', 'base_link', 'camera_link']
        ),
    ])