#!/usr/bin/env python3
"""
Motor Controller for ESP32 over Serial
Differential drive robot with no odometry feedback
"""
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import serial
import threading
import time

class ESP32MotorController(Node):
    def __init__(self):
        super().__init__('esp32_motor_controller')
        
        # Parameters
        self.declare_parameter('port', '/dev/ttyUSB0')
        self.declare_parameter('baudrate', 115200)
        self.declare_parameter('wheel_separation', 0.75)  # meters
        self.declare_parameter('wheel_radius', 0.15)      # meters
        self.declare_parameter('max_pwm', 255)
        self.declare_parameter('min_pwm', 30)  # Deadband
        
        # Current command
        self.current_cmd = Twist()
        self.cmd_lock = threading.Lock()
        
        # Subscribe to cmd_vel from Nav2
        self.subscription = self.create_subscription(
            Twist,
            '/cmd_vel_nav',
            self.cmd_vel_callback,
            10)
        
        # Connect to ESP32
        self.connect_esp32()
        
        # Start command sending thread
        self.cmd_thread = threading.Thread(target=self.command_sending_thread)
        self.cmd_thread.daemon = True
        self.cmd_thread.start()
        
        self.get_logger().info("ESP32 Motor Controller ready")
    
    def connect_esp32(self):
        """Connect to ESP32 serial port"""
        port = self.get_parameter('port').value
        baudrate = self.get_parameter('baudrate').value
        
        # Try common baudrates
        for baud in [baudrate, 9600, 57600, 115200]:
            try:
                self.serial = serial.Serial(port, baud, timeout=1)
                self.get_logger().info(f"Connected to ESP32 on {port} at {baud} baud")
                
                # Wait for ESP32 to initialize
                time.sleep(2)
                
                # Send test command
                self.send_motor_command(0, 0)
                return
                
            except Exception as e:
                self.get_logger().debug(f"Failed at {baud}: {e}")
                continue
        
        self.get_logger().error(f"Failed to connect to ESP32 on {port}")
        self.serial = None
    
    def cmd_vel_callback(self, msg):
        """Handle incoming velocity commands"""
        with self.cmd_lock:
            self.current_cmd = msg
    
    def twist_to_motor_speeds(self, linear, angular):
        """Convert Twist to individual motor speeds"""
        wheel_sep = self.get_parameter('wheel_separation').value
        wheel_radius = self.get_parameter('wheel_radius').value
        
        # Differential drive equations
        left_speed = (linear - (angular * wheel_sep / 2)) / wheel_radius
        right_speed = (linear + (angular * wheel_sep / 2)) / wheel_radius
        
        # Convert to PWM (simplified)
        max_pwm = self.get_parameter('max_pwm').value
        min_pwm = self.get_parameter('min_pwm').value
        
        # Scale factor - tune this for your robot
        scale = 50.0  # PWM per m/s
        
        left_pwm = int(left_speed * scale)
        right_pwm = int(right_speed * scale)
        
        # Apply deadband
        if abs(left_pwm) < min_pwm and left_pwm != 0:
            left_pwm = min_pwm if left_pwm > 0 else -min_pwm
        if abs(right_pwm) < min_pwm and right_pwm != 0:
            right_pwm = min_pwm if right_pwm > 0 else -min_pwm
        
        # Limit to max PWM
        left_pwm = max(min(left_pwm, max_pwm), -max_pwm)
        right_pwm = max(min(right_pwm, max_pwm), -max_pwm)
        
        return left_pwm, right_pwm
    
    def send_motor_command(self, left_pwm, right_pwm):
        """Send motor command to ESP32"""
        if not self.serial:
            return False
        
        try:
            # Simple protocol: "L{pwm}R{pwm}\n"
            command = f"L{left_pwm}R{right_pwm}\n"
            self.serial.write(command.encode('ascii'))
            return True
            
        except Exception as e:
            self.get_logger().error(f"Failed to send motor command: {e}")
            
            # Try to reconnect
            try:
                self.serial.close()
            except:
                pass
            
            self.connect_esp32()
            return False
    
    def command_sending_thread(self):
        """Thread that sends commands at fixed rate"""
        rate = 20  # Hz
        
        while rclpy.ok():
            with self.cmd_lock:
                cmd = self.current_cmd
            
            # Convert to motor speeds
            left_pwm, right_pwm = self.twist_to_motor_speeds(
                cmd.linear.x, cmd.angular.z)
            
            # Send command
            self.send_motor_command(left_pwm, right_pwm)
            
            # Optional: log commands (reduce frequency for logging)
            # self.get_logger().debug(f"Motors: L={left_pwm}, R={right_pwm}")
            
            time.sleep(1.0 / rate)

def main():
    rclpy.init()
    node = ESP32MotorController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()