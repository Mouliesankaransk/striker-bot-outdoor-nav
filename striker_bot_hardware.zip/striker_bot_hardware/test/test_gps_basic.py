#!/usr/bin/env python3
"""
Basic GPS test for hardware
"""
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import NavSatFix
import time

class GPSTest(Node):
    def __init__(self):
        super().__init__('gps_test')
        
        self.gps_sub = self.create_subscription(
            NavSatFix,
            '/gps/fix',
            self.gps_callback,
            10)
        
        self.fix_count = 0
        self.start_time = time.time()
        
        self.get_logger().info("GPS Test - Waiting for GPS data...")
    
    def gps_callback(self, msg):
        self.fix_count += 1
        
        if msg.status.status >= 2:  # Valid fix
            self.get_logger().info(
                f"Fix #{self.fix_count}: "
                f"Lat={msg.latitude:.6f}, "
                f"Lon={msg.longitude:.6f}, "
                f"Alt={msg.altitude:.1f}m, "
                f"HDOP={msg.position_covariance[0]:.1f}"
            )
        else:
            self.get_logger().warn(f"No fix (status: {msg.status.status})")
        
        # Run for 30 seconds then exit
        if time.time() - self.start_time > 30:
            self.get_logger().info(f"Test complete. Received {self.fix_count} fixes.")
            rclpy.shutdown()

def main():
    rclpy.init()
    node = GPSTest()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()